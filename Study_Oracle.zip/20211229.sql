등수 구하기 - RANK() OVER(ORDER BY 순위결정정렬기준), -> 1, 2, 2, 4,...
            - DENSE_RANK() OVER(ORDER BY 순위결정정렬기준) -> 1, 2, 2, 3,...
              DENSE : 밀접한
SELECT  RANK() OVER(ORDER BY hire_date ASC) rank, --입사일 오름차순으로 10명 조회
        employee_id, last_name, hire_date
FROM    employees
--WHERE   rank <= 10; --XXX WHERE 절 ALIAS 사용 불가
--WHERE   RANK() OVER(ORDER BY hire_date ASC) <= 10; --XXX WHERE 절 그룹함수 사용불가
--HAVING  RANK() OVER(ORDER BY hire_date ASC) <= 10 --XXX HAVING : GROUP BY 절 필요
그래서, 인라인뷰 서브쿼리 사용

SELECT  e.*
FROM    ( SELECT  RANK() OVER(ORDER BY hire_date ASC) rank,
                  employee_id, last_name, hire_date
          FROM    employees ) e
WHERE   e.rank <= 10;

SELECT  e.*
FROM    ( SELECT  DENSE_RANK() OVER(ORDER BY hire_date ASC) rank,
                  employee_id, last_name, hire_date
          FROM    employees ) e
WHERE   e.rank <= 10;

8장. DML
: DQL(SELECT) + DML(INSERT, UPDATE, DELETE) + TCL(COMMIT(작업확정), ROLLBACK(작업취소))
: TCL 과 함께 사용

1. 삽입저장 : INSERT
1.1 INSERT INTO 테이블명
    VALUES  (테이블구조 순서에 맞는 데이터값 목록);
1.2 INSERT INTO 테이블명(컬럼명 나열)
    VALUES  (나열된 컬럼명 순서에 맞는 데이터값 목록);
1.1 INSERT INTO 테이블명
    조회쿼리문( SELECT 문 )
    ☜ ITAS : VALUE 절 없이 SELECT 절 사용하여 서브쿼리로 테이블로부터 여러 데이터행 복사 저장
    INSERT 절의 저장 컬럼 목록과 SELECT 절의 컬럼목록 갯수가 같아야 함

DESC  departments;
이름              널?       유형           
--------------- -------- ------------ 
DEPARTMENT_ID   NOT NULL NUMBER(4)    
DEPARTMENT_NAME NOT NULL VARCHAR2(30) 
MANAGER_ID               NUMBER(6)    
LOCATION_ID              NUMBER(4) 

1.1 
INSERT INTO 테이블명
VALUES ( 테이블 구조 순서에 맞는 데이터 값 목록 );

01. departments 테이블에 새로운 부서를 등록한다.

INSERT INTO departments
VALUES (300, '영업부', NULL, NULL); --NULL의 표현 : NULL, '' ☜ OOO, 'NULL' ☜ XXX

SELECT  *
FROM    departments
ORDER BY department_id DESC;

INSERT INTO departments
VALUES (310, '개발부', NULL, '');

SELECT  *
FROM    departments
ORDER BY department_id DESC;

INSERT INTO departments
VALUES (320, '총무부', DEFAULT, DEFAULT); --모든 데이터의 기본값(DEFAULT)은 NULL 이다.

SELECT  *
FROM    departments
ORDER BY department_id DESC;

ROLLBACK;

SELECT  *
FROM    departments
ORDER BY department_id DESC;

1.2 
INSERT INTO 테이블명 ( 컬럼명1, 컬럼명2, ... )
VALUES  ( 나열된 컬럼명에 매칭될 데이터값의 목록 );

INSERT INTO 테이블명 ( 테이블구조에서 NOT NULL 인 컬럼 반드시 포함 + 추가할 컬럼 목록 )
VALUES  ( 나열된 컬럼명에 매칭될 데이터값의 목록 );

DESC  departments;
이름              널?       유형           
--------------- -------- ------------ 
DEPARTMENT_ID   NOT NULL NUMBER(4)    
DEPARTMENT_NAME NOT NULL VARCHAR2(30) 
MANAGER_ID               NUMBER(6)    
LOCATION_ID              NUMBER(4)

INSERT INTO departments (department_id, department_name)
VALUES ( 300,'개발부' );

INSERT INTO departments (department_id)
VALUES (30); --저장불가

DESC  employees;
이름             널?       유형           
-------------- -------- ------------ 
EMPLOYEE_ID    NOT NULL NUMBER(6)    
FIRST_NAME              VARCHAR2(20) 
LAST_NAME      NOT NULL VARCHAR2(25) 
EMAIL          NOT NULL VARCHAR2(25) 
PHONE_NUMBER            VARCHAR2(20) 
HIRE_DATE      NOT NULL DATE         
JOB_ID         NOT NULL VARCHAR2(10) 
SALARY                  NUMBER(8,2)  
COMMISSION_PCT          NUMBER(2,2)  
MANAGER_ID              NUMBER(6)    
DEPARTMENT_ID           NUMBER(4)

INSERT INTO employees ( employee_id, first_name, last_name, email, hire_date, 
                        job_id, salary, department_id )
VALUES  ( 301, '길동','홍' ,'GILDONG',TO_DATE('10/10/10'),'MK_REP',3000,300 );

COMMIT;

SELECT  *
FROM    employees
ORDER BY employee_id DESC;

1.3 ☜ ITAS
INSERT INTO 테이블명
  조회쿼리문(SELECT 문);
  여러행을 한번에 삽입저장

- departments 테이블에 새로운 department_id(기존 department_id 에 1 더하여) 를
  departments 테이블의 정보를 복사하여 삽입저장하자.

SELECT  *
FROM    departments;
  
ITAS :
INSERT INTO departments
  SELECT  department_id + 1, department_name, manager_id, location_id
  FROM    departments;

SELECT  *
FROM    departments;

ROLLBACK;

SELECT  *
FROM    departments;

--------------------------------------------------------------------------------
CTAS(Create Table As Select) --NOT NULL 이외의 제약조건(Primary Key 등)은 복사되지 않는다.
CREATE TABLE 테이블명 AS
  SELECT 쿼리문;

다른테이블에 데이터 조회해서 새로운 테이블 생성 후 삽입 저장
CREATE  TABLE emp AS
  SELECT  employee_id id, first_name 이름, last_name 성, hire_date 입사일, 
          job_id 업무코드, department_id dept_id
  FROM    employees;
  
다른테이블에 데이터 조회해서 새로운 테이블만 생성(엉터리 조건 줘서 테이블만 생성)

CREATE  TABLE emp01 AS
  SELECT  employee_id id, first_name 이름, last_name 성, hire_date 입사일, 
          job_id 업무코드, department_id dept_id
  FROM    employees
  WHERE   1 = 2; --엉터리조건
--------------------------------------------------------------------------------
테이블 삭제
DROP TABLE emp01;


* 삭제된 테이블 복구
FLASHBACK TABLE 테이블명 TO BEFORE DROP;
FLASHBACK TABLE emp01 TO BEFORE DROP;

DROP TABLE emp01;
DROP TABLE emp;

휴지통 비우기
PURGE RECYCLEBIN;

CREATE  TABLE emp AS
  SELECT  employee_id id, first_name, last_name, hire_date, 
          job_id, department_id dept_id
  FROM    employees
  WHERE   1 = 2; --엉터리조건

DESC emp;

이름         널?       유형           
---------- -------- ------------ 
ID                  NUMBER(6)    
FIRST_NAME          VARCHAR2(20) 
LAST_NAME  NOT NULL VARCHAR2(25) 
HIRE_DATE  NOT NULL DATE         
JOB_ID     NOT NULL VARCHAR2(10) 
DEPT_ID             NUMBER(4)

employees 테이블의 10번, 20번 부서원들의 정보를 복사하여
emp테이블엣 데이터행을 삽입저장한다.












