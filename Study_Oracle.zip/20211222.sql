05. 사번, 성, 부서코드, 부서명, 업무코드, 업무제목 조회
SELECT  e.employee_id, e.last_name, e.department_id,
        d.department_name, e.job_id, j.job_title
FROM    employees e, departments d, jobs j
WHERE   e.department_id = d.department_id
AND     e.job_id = j.job_id;

06. 사번이 101번인 사원의 사번, 이름, 부서명, 업무제목 정보 조회
SELECT  e.employee_id, e.first_name, d.department_name, j.job_title
FROM    employees e, departments d, jobs j
WHERE   e.department_id = d.department_id
AND     e.job_id = j.job_id
AND     e.employee_id = 101;

07. 사번이 100,120,130,140 인 사원들의
사번, 성, 부서코드, 부서명을 조회
SELECT  e.employee_id, e.last_name, e.department_id, d.department_name
FROM    employees e, departments d
WHERE   e.department_id = d.department_id
AND     e.employee_id IN(100,120,130,140);

08. 매니저가 없는 사원의 사번, 이름, 업무제목을 조회한다.
SELECT  e.employee_id, e.first_name, j.job_title
FROM    employees e, jobs j
WHERE   e.job_id = j.job_id
AND     e.manager_id IS NULL; --매니저가 없는

3. NON-EQUI 조인
: 비교연산자(<, <=, >, >=), 범위연산자(BETWEEN), IN 연산자 등의
동등연산자 이외의 연산자를 사용하는 조인형식
조인하는 컬럼이 일치하지 않게 사용하는 조인조건으로 거의 사용하지 않는다
01. employees 테이블의 급여가 jobs 테이블의 최고급여(max_salary)/최저급여(min_salary)
범위 내에 있는 50번 부서의 
사번, 이름, 급여, 업무제목 조회
SELECT  e.employee_id, e.first_name, e.salary, j.job_title
FROM    employees e, jobs j
WHERE   e.job_id = j.job_id
AND     e.salary BETWEEN j.min_salary AND j.max_salary
AND     e.department_id = 50;

4. OUTER JOIN : NULL 값이 생략되는 정보도 포함해서 표시하기 위한 조인, 합집합
EQUI JOIN 은 조인조건에 동등비교연산자(=)로 비교한 형태,
즉, 테이블들 간에 공통으로 만족되는 값을 가진 경우의 결과를 반환

하지만, OUTER JOIN 은 만족되는 값이 없는 경우의 결과까지 반환한다.
만족되는 값이 없는 테이블 컬럼에 (+) 를 표시한다.
즉, 데이터 행의 누락이 발생하지 않도록 하기 위한 조인기법
조인 조건식에서 (+) 기호를 데이터 행이 부족한 조인조건쪽에 붙여준다.
--------------------------------------------------------------------------------
employees             departments(+)              locations(+)
사번 부서코드         부서코드  부서명  위치코드  위치코드   부서위치                                                              
100  10               10        영업부  1600      1600       광주                                                
101  20               20        총무부  1700      1700       서울                                        
178  NULL             NULL      NULL    NULL      NULL       NULL                                          
--------------------------------------------------------------------------------
01. 모든 사원의 사번, 성, 부서코드, 부서명 조회
SELECT  e.employee_id, e.last_name, e.department_id, d.department_name
FROM    employees e, departments d
WHERE   e.department_id = d.department_id(+);

* NULL 확인
e.department_id 의 NULL갯수
SELECT  COUNT(*) cnt --1
FROM    employees
WHERE   department_id IS NULL;

d.department_id 의 NULL갯수
SELECT  COUNT(*) cnt --0
FROM    departments
WHERE   department_id IS NULL;

사원테이블에는 부서배치 받지 않은 사원 데이터 행(NULL)이 있고,
부서테이블에는 부서코드가 NULL 인것에 대한 데이터 행이 없으므로,
(만족되는 데이터가 없을 수도 있는 쪽 조인 컬럼에 (+) 를 추가)
부서테이블의 부서코드 쪽에 OUTER 기호(+) 를 붙인다.

--------------------------------------------------------------------------------
OUTER JOIN -> LEFT/RIGHT OUTER JOIN : 기준이 되는 테이블 방향으로 조인한다.
LEFT  OUTER JOIN : 왼  쪽 테이블 기준으로 NULL 포함하여 모두 출력(등호의 오른쪽에 (+)가 붙음)
RIGHT OUTER JOIN : 오른쪽 테이블 기준으로 NULL 포함하여 모두 출력(등호의 왼  쪽에 (+)가 붙음)
--------------------------------------------------------------------------------

02. 모든 사원의 사번, 성, 업무코드, 업무제목
SELECT  e.employee_id, e.last_name, e.job_id, j.job_title
FROM    employees e, jobs j
WHERE   e.job_id = j.job_id;

NULL 갯수 파악
employees 테이블
SELECT  COUNT(*) --0
FROM    employees
WHERE   job_id IS NULL;

jobs 테이블
SELECT  COUNT(*) --0
FROM    jobs
WHERE   job_id IS NULL;

03. 모든 사원의 사번, 성, 부서명, 업무제목 조회
SELECT  e.employee_id, e.last_name, d.department_name, j.job_title
FROM    employees e, departments d, jobs j
WHERE   e.department_id = d.department_id(+)
AND     e.job_id = j.job_id;

04. 모든 사원의 사번, 성, 부서코드, 부서명, 위치코드, 도시 조회
SELECT  e.employee_id, e.last_name, e.department_id, d.department_name, d.location_id, l.city
FROM    employees e, departments d, locations l
WHERE   e.department_id = d.department_id(+)
--AND     d.location_id(+) = l.location_id(+); --XXX outer-join된 테이블은 1개만 지정할 수 있습니다
AND     d.location_id = l.location_id(+); --outer-join된 테이블은 1개만 지정할 수 있습니다

05. 모든 사원의 사번, 성, 부서코드, 부서명, 업무코드, 업무제목 조회
SELECT  e.employee_id, e.last_name, d.department_name, e.job_id, j.job_title
FROM    employees e, departments d, jobs j
WHERE   e.department_id = d.department_id(+)
AND     e.job_id = j.job_id;

5. SELF 조인 
  : 하나의 테이블을 두번 명시하여 동일한 테이블 두개로부터 JOIN을 통해
    데이터를 조회하여 결과를 반환, 즉 한테이블 내에서 두 데이터 컬럼이 연관관계가 있다.
    
employees 테이블에는 사원정보, 관리자 정보도 있다.
동일한 테이블을 여러개 준비하여 테이블 조인하는 SELF JOIN

01. 모든 사원의 사번, 이름, 매니저사번, 매니저이름 조회
SELECT  e.employee_id 사번, e.first_name 이름, e.manager_id 매니저사번, 
        m.first_name 매니저이름
FROM    employees e, employees m
WHERE   e.manager_id = m.employee_id(+)
ORDER BY 1;

5.6 ANSI JOIN
: 모든 DBMS에서 공통적으로 사용할 수 있는 국제 표준 JOIN 형식

1. INNER JOIN(오라클의 EQUI JOIN), 교집합
--------------------------------------------------------------------------------
오라클 조인                          |  ANSI JOIN
--------------------------------------------------------------------------------
5. SELECT 컬럼명1, 컬럼명2           | SELECT   컬럼명1, 컬럼명2
1. FROM   테이블명1, 테이블명2       | FROM     테이블명1 INNER JOIN 테이블명2
2. WHERE  조인조건식                 | ON       조인조건식
                                     | (또는)
                                     | USING    (조인컬럼명만)
   AND    일반조건식                 | WHERE    일반조건식 
3. GROUP BY 그룹                     | GROUP BY
4. HAVING   그룹함수조건             | HAVING
6. ORDER BY 정렬기준                 | ORDER BY
--------------------------------------------------------------------------------

조인조건절 
ON 절      - 조인조건식(테이블명.컬럼명 = 테이블명.컬럼명)
             조인하는 컬럼명이 동일하면 반드시 테이블명을 명시해야 한다. 
USING 절   - (조인컬럼명만) ☜ 중요!!! 괄호안에 컬럼명만
             조인하는 컬럼명이 동일한 경우만 사용가능
             USING 절에 사용하는 컬럼에 대해서는 테이블명을 절대로 명시해서는 안된다.

01. 부서코드가 60번인 사번, 성, 부서코드, 부서명 조회
오라클 조인
SELECT  e.employee_id, e.last_name, e.department_id, d.department_name
FROM    employees e, departments d
WHERE   e.department_id = d.department_id
AND     e.department_id = 60;

ANSI JOIN ON
SELECT  e.employee_id, e.last_name, e.department_id, d.department_name
FROM    employees e INNER JOIN departments d
ON      e.department_id = d.department_id
WHERE   e.department_id = 60;

ANSI JOIN USING
SELECT  e.employee_id, e.last_name, department_id, d.department_name
FROM    employees e INNER JOIN departments d
USING   (department_id)
WHERE   department_id = 60;

02. 사번, 성, 업무코드, 업무제목 조회
오라클조인
SELECT  e.employee_id, e.last_name, e.job_id, j.job_title
FROM    employees e, jobs j
WHERE   e.job_id = j.job_id;

ANSI JOIN ON
SELECT  e.employee_id, e.last_name, e.job_id, j.job_title
FROM    employees e INNER JOIN jobs j
ON      e.job_id = j.job_id;

ANSI JOIN USING
SELECT  e.employee_id, e.last_name, job_id, j.job_title
FROM    employees e INNER JOIN jobs j
USING   (job_id);

03. 업무코드가 clerk 종류인 업무형태를 하는 사번, 성, 업무코드, 업무제목 조회
오라클조인
SELECT  e.employee_id, e.last_name, e.job_id, j.job_title
FROM    employees e, jobs j
WHERE   e.job_id = j.job_id
AND     LOWER(e.job_id) LIKE '%clerk%';

ANSI JOIN ON
SELECT  e.employee_id, e.last_name, e.job_id, j.job_title
FROM    employees e INNER JOIN jobs j
ON      e.job_id = j.job_id
WHERE   LOWER(e.job_id) LIKE '%clerk%';

ANSI JOIN USING
SELECT  e.employee_id, e.last_name, job_id, j.job_title
FROM    employees e INNER JOIN jobs j
USING   (job_id)
WHERE   LOWER(job_id) LIKE '%clerk%';

04. 부서코드, 부서명, 위치코드, 도시 조회
오라클조인
SELECT  d.department_id, d.department_name, d.location_id, l.city
FROM    departments d, locations l
WHERE   d.location_id = l.location_id;

ANSI JOIN ON
SELECT  d.department_id, d.department_name, d.location_id, l.city
FROM    departments d INNER JOIN locations l
ON      d.location_id = l.location_id;

ANSI JOIN USING
SELECT  d.department_id, d.department_name, location_id, l.city
FROM    departments d INNER JOIN locations l
USING   (location_id);

05. 매니저의 부서가 60 이상인 부서에 속한 사원들의
사번, 성, 매니저사번, 매니저 성 조회
오라클조인
SELECT  e.employee_id, e.last_name, m.manager_id, m.last_name
FROM    employees e, employees m   
WHERE   e.manager_id = m.employee_id
AND     m.department_id >= 60;

ANSI JOIN ON
SELECT  e.employee_id, e.last_name, m.manager_id, m.last_name
FROM    employees e INNER JOIN employees m   
ON      e.manager_id = m.employee_id
WHERE   m.department_id >= 60;

ANSI JOIN USING --조인하는 컬럼명이 다르므로 조인 불가
--------------------------------------------------------------------------------
※ 조인하는 테이블이 3개 이상일 경우
첫번째 조인의 결과에 두번째 조인을 추가하는 형태로 사용
--------------------------------------------------------------------------------

06. 부서코드 10,20,40,60 인 부서에 속한 사원들의
사번, 성, 부서코드, 부서명, 업무코드, 업무제목 조회

오라클조인
SELECT  e.employee_id, e.last_name, e.department_id, d.department_name, e.job_id, j.job_title
FROM    employees e, departments d, jobs j
WHERE   e.department_id = d.department_id
AND     e.job_id = j.job_id
AND     e.department_id IN (10,20,40,60);

ANSI JOIN ON
SELECT  e.employee_id, e.last_name, e.department_id, d.department_name, e.job_id, j.job_title
FROM    employees e INNER JOIN departments d
ON      e.department_id = d.department_id
INNER JOIN jobs j
ON      e.job_id = j.job_id
WHERE   e.department_id IN (10,20,40,60);

ANSI JOIN USING
SELECT  e.employee_id, e.last_name, department_id, d.department_name, job_id, j.job_title
FROM    employees e INNER JOIN departments d
USING   (department_id)
INNER JOIN jobs j
USING   (job_id)
WHERE   department_id IN (10,20,40,60);

--------------------------------------------------------------------------------
2. OUTER JOIN
FROM 절에 LEFT OUTER JOIN / RIGHT OUTER JOIN 을 사용하고
JOIN 조건은 ON/USING 절에 명시한다.

OUTER JOIN ☞ LEFT/RIGHT OUTER JOIN : 기준이 되는 테이블 방향으로 조인한다.
--------------------------------------------------------------------------------
01. 모든 사원들의 사번, 성, 부서코드, 부서명 조회
오라클 조인
SELECT  e.employee_id, e.last_name, e.department_id, d.department_name
FROM    employees e, departments d
WHERE   e.department_id = d.department_id(+);

ANSI OUTER JOIN ON
SELECT  e.employee_id, e.last_name, e.department_id, d.department_name
FROM    employees e LEFT OUTER JOIN departments d
--FROM    departments d RIGHT OUTER JOIN employees e
ON      NVL(e.department_id,0) = NVL(d.department_id,0);

ANSI OUTER JOIN USING
SELECT  e.employee_id, e.last_name, department_id, d.department_name
FROM    employees e LEFT OUTER JOIN departments d
USING   (department_id);

02. 모든 사원들이 사번, 성, 부서코드, 부서명, 도시 조회
SELECT  e.employee_id, e.last_name, e.department_id, d.department_name, l.city
FROM    employees e, departments d, locations l
WHERE   e.department_id = d.department_id(+)
AND     d.location_id = l.location_id(+);

ANSI OUTER JOIN ON
SELECT  e.employee_id, e.last_name, e.department_id, d.department_name, l.city
FROM    employees e LEFT OUTER JOIN departments d
ON      e.department_id = d.department_id
LEFT OUTER JOIN locations l
ON      d.location_id = l.location_id;

ANSI OUTER JOIN USING
SELECT  e.employee_id, e.last_name, department_id, d.department_name, l.city
FROM    employees e LEFT OUTER JOIN departments d
USING   (department_id)
LEFT OUTER JOIN locations l
USING   (location_id);

03. 모든 사원들의 사번, 성, 매니저사번, 매니저 성 조회
오라클 조인
SELECT  e.employee_id, e.last_name, e.manager_id, m.last_name
FROM    employees e, employees m
WHERE   e.manager_id = m.employee_id(+);

ANSI OUTER JOIN ON
SELECT  e.employee_id, e.last_name, e.manager_id, m.last_name
FROM    employees e LEFT OUTER JOIN employees m
ON      e.manager_id = m.employee_id;

ANSI OUTER JOIN USING --컬럼명이 다르므로 사용불가













































































































