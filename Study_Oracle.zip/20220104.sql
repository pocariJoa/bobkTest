10장. 
무결성 제약조건(INTEGRITY CONSTRAINT) - 정확성, 정합성, 무결성을 보장하기 위해
- 테이블에 잘못된 데이터의 입력을 막기 위해 일정한 규칙을 주는것
- 제약조건명은 30자 까지 지정 가능


CONSTRAINT : 제약사항
정합성 : (가지런할 정, 합할 합, 성질 성) 어떤 사람들의 언어 혹은 논변이 그것을 포함하는 
전제들의 체계를 무너뜨리지 않고 잘 어울린다.
무결성 : 데이터의 정확성과 일관성을 유지하고 데이터에 결속과 부정합이 없음을 보증하는것
       : 학년을 입력할때 1,2,3,4 학년까지만 존재하는데 5학년이 입력되면 무결성이 어긋낫다라고 표현
       
--**** 제약조건
--**** NOT NULL, DEFAULT, CHECK, UNIQUE, PRIMARY KEY, FOREIGN KEY(DEFAULT 는 제약조건은 아님)

※ 테이블 생성시 제약조건
--------------------------------------------------------------------------------
제약조건                    | 기능
--------------------------------------------------------------------------------
- NOT NULL(컬럼레벨에서만,  | NULL 값 입력금지, 테이블 생성시 컬럼레벨에서만 정의
      NULL값 입력 금지)     | 컬럼레벨만 ☞ id VARCHAR2(20) NOT NULL
--------------------------------------------------------------------------------
- DEFAULT(컬럼레벨에서만,   | 데이터 입력 수정할때 값 미정시 기본값 정의,
      기본값지정,           | 테이블 생성시 컬럼레벨 정의 방식으로만 정의
      (제약조건은 아님)     | 컬럼레벨만 ☞ gender CHAR(3) DEFAULT '남'
--------------------------------------------------------------------------------
- CHECK(입력값의 제한, 즉   | 조건으로 설정된 값만 입력 허용
        설정값만 허용       | 컬럼레벨 ☞ gender CHAR(3) CHECK ( gender IN ('남','여') )
(도메인 무결성 제약조건)    | 테이블레벨 ☞ CHECK( gender IN ('남','여') )
--------------------------------------------------------------------------------
- UNIQUE(개체무결성,        | 중복값 입력 금지, NULL은 중복입력 가능, NOT NULL과 함께 사용가능
중복값 입력 금지)           | 컬럼레벨 ☞ job VARCHAR2(15) UNIQUE
                            | 테이블레벨 ☞ UNIQUE(job)
                            | 2개 이상의 컬럼을 이용하여 기본키 지정(복합키)
--------------------------------------------------------------------------------
- PRIMARY KEY(개체무결성)   | NOT NULL + UNIQUE, 2개 이상의 컬럼을 이용하여 기본키 지정(복합키)
  NOT NULL + UNIQUE         | 컬럼레벨 ☞ id NUMBER(8) PRIMARY KEY
                            | 테이블레벨 ☞ PRIMARY KEY(id)
--------------------------------------------------------------------------------
- FOREIGN KEY(참조 무결성,  | 다른 테이블의 컬럼을 조회해서 무결성 검사
다른테이블의 PK,UK컬럼 참조)| 컬럼레벨 ☞ dept_id NUMBER(4) REFERENCES departments(department_id)
(부모테이블의 PK, UK만 참조)| 테이블레벨 ☞ FOREIGN KEY(dept_id) REFERENCES departments(department_id)
--------------------------------------------------------------------------------

* 제약조건에 이름지정하기(관리 목적으로 생성)
- 이름을 지정하지 않으면 자동으로 생성됨(SYS...로 시작)
- 나중에 제약조건을 비활성화 하거나 삭제하는 등의 관리를 위해서는 
  제약조건에 이름을 지정해주는것이 좋다.

--제약조건 선언 : COLUMN 레벨 정의방식, TABLE 레벨 정의 방식
--------------------------------------------------------------------------------
--1.1. 컬럼레벨의 제약조건 기술 방법(컬럼 정의시 그 라인 안에서 제약조건을 정의해주는것)
--------------------------------------------------------------------------------
☞ 컬럼명 데이터타입(크기) [CONSTRAINT 제약조건명(테이블명_컬럼명_제약조건약어) 제약조건]
--------------------------------------------------------------------------------
CREATE  TABLE 테이블명 (
  컬럼명 데이터타입(크기) [CONSTRAINT 제약조건명(테이블명_컬럼명_제약조건약어) 제약조건],
  ...
);

컬럼레벨 정의방식
--------------------------------------------------------------------------------
CREATE  TABLE   emp000 (
  empno   NUMBER(4)     PRIMARY KEY,
  ename   VARCHAR2(15)  NOT NULL,
  job     VARCHAR2(15)  UNIQUE,
  deptno  NUMBER(2)     REFERENCES      dept(deptno),
  gender  CHAR(3)       DEFAULT '남'    CHECK( gender IN ('남','여') )
);
--------------------------------------------------------------------------------

제약조건명 추가한 컬럼레벨 정의방식(컬럼 정의시 그 라인에서 정의 하는것)
--------------------------------------------------------------------------------
CREATE  TABLE   emp000 (
  empno   NUMBER(4)     CONSTRAINT emp000_empno_pk  PRIMARY KEY,
  ename   VARCHAR2(15)  CONSTRAINT emp000_ename_nn  NOT NULL,
  job     VARCHAR2(15)  CONSTRAINT emp000_job_uk    UNIQUE,
  deptno  NUMBER(2)     CONSTRAINT emp000_deptno_fk REFERENCES     dept(deptno),
--                                                  REFERENCES 부모테이블(참조되는컬럼명),      
  gender  CHAR(3)       DEFAULT '남' CONSTRAINT emp000_gender_ck   CHECK( gender IN ('남','여') )
--                      ￣￣￣￣￣￣ DEFAULT 는 컬럼의 데이터 타입 바로 옆에 정의해야함
);
--------------------------------------------------------------------------------
- 관계에 대한 제약조건이 복잡
- 참조하는 테이블(즉, 기본키가 있는 테이블)이 먼저 생성 되어 있어야 함
- 외래키가 참조하는 컬럼은 참조하는 테이블의 기본키어야 함
- REFERENCES dept(deptno) 로 부모테이블과 부모테이블 컬럼의 PK 가 필요함
- 그래서, dept 테이블 생성 후 deptno에 PK 지정


-- CTAS로 departments 테이블을 이용하여 dept 테이블 생성하기
department_id     ☞ deptno 로 ALIAS    
department_name   ☞ deptname 로 ALIAS
manager_id        ☞ manager_id
location_id       ☞ location_id

CREATE  TABLE dept AS --CTAS : NOT NULL 이외의 조건(PRIMARY KEY 등)은 복사되지 않는다
  SELECT  department_id deptno, department_name deptname, manager_id, location_id
  FROM    departments;

DESC  departments;
이름              널?       유형           
--------------- -------- ------------ 
DEPARTMENT_ID   NOT NULL NUMBER(4)    
DEPARTMENT_NAME NOT NULL VARCHAR2(30) 
MANAGER_ID               NUMBER(6)    
LOCATION_ID              NUMBER(4)

DESC  dept;
이름          널?       유형           
----------- -------- ------------ 
DEPTNO               NUMBER(4)    --☜ PRIMARY KEY 는 복사 되지 않음
DEPTNAME    NOT NULL VARCHAR2(30) 
MANAGER_ID           NUMBER(6)    
LOCATION_ID          NUMBER(4)

dept 테이블에 deptno 컬럼에 PRIMARY KEY 지정하기
ALTER TABLE dept
MODIFY ( deptno PRIMARY KEY );

DESC  dept;



--------------------------------------------------------------------------------
--1.1. 테이블레벨의 제약조건 기술 방법(컬럼 정의 후 다시 아래에서 제약조건 지정하는것)
--------------------------------------------------------------------------------
CONSTRAINT 제약조건명(테이블명약어_컬럼명약어_제약조건약어) 제약조건
--------------------------------------------------------------------------------
CREATE  TABLE 테이블명 (
  컬럼명   데이터타입(크기),
  ....,
  CONSTRAINT  제약조건명 제약조건,
  ....
);

테이블레벨 정의방식
--------------------------------------------------------------------------------
CREATE  TABLE   emp001 (
  empno   NUMBER(4),     --PRIMARY KEY,
  ename   VARCHAR2(15)   NOT NULL,
  job     VARCHAR2(15),  --UNIQUE,
  deptno  NUMBER(2),     --REFERENCES      dept(deptno),
  gender  CHAR(3)        DEFAULT '남',    --CHECK( gender IN ('남','여') )
  
  PRIMARY KEY (empno),
  UNIQUE  (job),
  FOREIGN KEY(deptno) REFERENCES dept(deptno),
  CHECK( gender IN ('남','여') )
);

CREATE  TABLE   emp002 (
  empno   NUMBER(4),     --PRIMARY KEY,
  ename   VARCHAR2(15)   CONSTRAINT emp002_ename_nn NOT NULL,
  job     VARCHAR2(15),  --UNIQUE,
  deptno  NUMBER(2),     --REFERENCES      dept(deptno),
  gender  CHAR(3)        DEFAULT '남',    --CHECK( gender IN ('남','여') )
  
  CONSTRAINT emp002_empno_pk  PRIMARY KEY(empno),
  CONSTRAINT emp002_job_uk    UNIQUE  (job),
  CONSTRAINT emp002_deptno_fk FOREIGN KEY(deptno) REFERENCES dept(deptno),
  CONSTRAINT emp002_gender_ck CHECK( gender IN ('남','여') )
);


테이블 생성 후 제약조건 지정하기
emp000테이블에서 
--------------------------------------------------------------------------------
1. empno 의 PRIMARY KEY 삭제
제약조건명 없을때 emp000 테이블의 empno 에 PRIMARY KEY 삭제
ALTER TABLE emp000
DROP PRIMARY KEY;

제약조건명 있을때 emp000 테이블의 empno 에 PRIMARY KEY 삭제
ALTER TABLE emp000
DROP CONSTRAINT emp000_empno_pk; --DROP CONSTRAINT 제약조건명
--DROP CONSTRAINT SYS_C008416;

2. empno 의 PRIMARY KEY 추가
제약조건명 없이 emp000 테이블의 empno 에 PRIMARY KEY 추가
ALTER TABLE emp000
ADD PRIMARY KEY (empno);

제약조건명 주고 emp000 테이블의 empno 에 PRIMARY KEY 추가
ALTER TABLE emp000
ADD CONSTRAINT  emp000_empno_pk PRIMARY KEY(empno);
--------------------------------------------------------------------------------
3. ename 컬럼의 NOT NULL 을 NULL 로 변경
제약조건명 없는 ename 컬럼의 NOT NULL을 NULL로 변경
ALTER TABLE emp000
MODIFY ename NULL;
--MODIFY (ename NULL);
제약조건명 있는 ename 컬럼의 NOT NULL을 NULL로 변경
ALTER TABLE emp000
DROP CONSTRAINT emp000_ename_nn;

4. ename 의 NOT NULL 추가
제약조건명 없이 ename 의 NULL 을 NOT NULL로 변경
ALTER TABLE emp000
MODIFY (ename NOT NULL);

제약조건명 주고 ename 의 NULL 을 NOT NULL로 변경 --여러번 작업, 이단아
  --NULL로 만들고 나서는 NOT NULL 제약조건명 이름 지정 불가
ALTER TABLE emp000
MODIFY (ename NOT NULL); --SYS_C008417

자동으로 생성된 SYS... 를 RENAME CONSTRAINT 로 변경
ALTER TABLE emp000
RENAME CONSTRAINT SYS_C008417 TO emp000_ename_nn;
--------------------------------------------------------------------------------
5. job의 UNIQUE 삭제
제약조건명 없을때 job 의 UNIQUE 삭제
ALTER TABLE emp000
DROP  UNIQUE; --XXX, 자동으로 생성된 제약조건명 찾아서 제약조건명 삭제
제약조건명 있을때 job 의 UNIQUE 삭제
ALTER TABLE emp000
DROP CONSTRAINT SYS_C008419;

6. job의 UNIQUE 추가
제약조건명 없이 job 의 UNIQUE 추가
ALTER TABLE emp000
ADD UNIQUE(job);

제약조건명 주고 job 의 UNIQUE 추가
ALTER TABLE emp000
ADD CONSTRAINT emp000_job_uk UNIQUE(job);
--------------------------------------------------------------------------------
7. gender의 CHECK 삭제
제약조건명 없을때 gender 의 CHECK 삭제
ALTER TABLE emp000
DROP CHECK; --XXX, 자동으로 생성된 SYS...시작된 제약조건명 찾아서 제약조건명 삭제

제약조건명 있을때 gender 의 CHECK 삭제
ALTER TABLE emp000
DROP CONSTRAINT emp000_gender_ck;

8. gender의 CHECK 추가
제약조건명 없이 gender의 CHECK 추가
ALTER TABLE emp000
ADD CHECK (gender IN ('남','여'));

제약조건명 주고 gender의 CHECK 추가
ALTER TABLE emp000
ADD CONSTRAINT emp000_gender_ck CHECK (gender IN ('남','여'));
--------------------------------------------------------------------------------
9. gender의 DEFAULT 삭제
제약조건명 없을때 gender 의 DEFAULT 삭제
ALTER TABLE emp000
MODIFY gender DEFAULT NULL;

제약조건명 있을때 gender 의 DEFAULT 삭제
DEFAULT는 제약조건이 아니어서 제약조건명이 없으므로 실행 불가

10. gender의 DEFAULT 추가
제약조건명 없이 gender의 DEFAULT 추가
ALTER TABLE emp000
MODIFY gender CHAR(3) DEFAULT '남';

제약조건명 주고 gender의 DEFAULT 추가
DEFAULT는 제약조건명이 없으므로 실행 불가

--------------------------------------------------------------------------------
11. deptno의 FOREIGN KEY 삭제
제약조건명 없을때 deptno 의 FOREIGN KEY 삭제
ALTER TABLE emp000
DROP FOREIGN KEY --XXX, 자동으로 생성된 SYS...로 시작된 제약조건명 찾아서 제약조건명 삭제
제약조건명 있을때 deptno 의 FOREIGN KEY 삭제
ALTER TABLE emp000
DROP CONSTRAINT emp000_deptno_fk;

12. deptno의 FOREIGN KEY 추가
제약조건명 없이 deptno의 FOREIGN KEY 추가
ALTER TABLE emp000
ADD FOREIGN KEY (deptno) REFERENCES dept(deptno)

제약조건명 주고 deptno의 FOREIGN KEY 추가
ALTER TABLE emp000
ADD CONSTRAINT emp000_deptno_fk FOREIGN KEY (deptno) REFERENCES dept(deptno);
--------------------------------------------------------------------------------











































































