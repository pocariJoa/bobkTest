※ GROUP BY 절 : 그룹별로 조회
전체 데이터 행을 하나의 그룹으로 보고 그룹함수루 데이터를 조회
특정 기준을 두어 기준으로 그룹을 짓고 그룹별로 하나의 결과를 

01. 사원들의 사번, 성, 부서코드, 급여 조회하여 부서코드 순으로 조회
SELECT LAST_NAME, SALARY, DEPARTMENT_ID, EMPLOYEE_ID
FROM EMPLOYEES
ORDER BY 3;

02.부서코드 50번의 급여평균 조회
SELECT ROUND(AVG(SALARY),2) AVG_SAL
FROM EMPLOYEES
WHERE DEPARTMENT_ID = 50;

03.부서코드 50번의 부서코드, 업무코드, 급여 평균 조회
SELECT DEPARTMENT_ID,JOB_ID, ROUND(AVG(SALARY),2) AVG_SAL
FROM EMPLOYEES
WHERE DEPARTMENT_ID = 50
GROUP BY DEPARTMENT_ID,JOB_ID;

5. SELECT 필드명1, 필드명2 ....
1. FROM 테이블명
2. WHERE 조건절
3. GROUP BY 그룹대상
4. HAVING 조건절
6. ORDER BY 정렬기준

SELECT 몰록에
       그룹함수를 사용한표현 ( COUNT, MAX, MIN, SUM, AVG 등등) 과
       그룹함수를 사용하지 않은 표현 (즉, 일반컬럼)과 함께 사용하면
반드시 그룹함수를 사용하지 않은 표현 (즉, 일반컬럼)
GROUP BY 절에 기준으로 명시해야한다
그러나, GROUP BY 절에 명시된 컬럼은 SELECT 절에 사용되지 않아도 된다
-----------------------------------
04. 각 부서별 급여평균, 급여합계 조회
SELECT DEPARTMENT_ID, ROUND(AVG(SALARY),2) AVG_SAL, ROUND(SUM(SALARY),2) SUM_SAL
FROM EMPLOYEES
GROUP BY DEPARTMENT_ID
ORDER BY 1;

05. 부서별 급여합계 급여평균, 부서원수 조회
SELECT DEPARTMENT_ID 부서, ROUND(AVG(SALARY),2) AVG_SAL, ROUND(SUM(SALARY),2) SUM_SAL, COUNT(EMPLOYEE_ID) 부서원수
FROM EMPLOYEES
WHERE DEPARTMENT_ID IS NOT NULL -- NULL 제외
GROUP BY DEPARTMENT_ID
ORDER BY 1;

06. 각 부서별, 업무별로 급여평균 조회
SELECT DEPARTMENT_ID 부서, JOB_ID 업무, ROUND(AVG(SALARY),2) AVG_SAL
FROM EMPLOYEES
WHERE DEPARTMENT_ID IS NOT NULL -- NULL 제외
GROUP BY DEPARTMENT_ID,JOB_ID 
ORDER BY 1;

07. 각 부서별, 업무별로 급여합계 급여평균 사원수 조회
SELECT DEPARTMENT_ID 부서, ROUND(AVG(SALARY),2) AVG_SAL, ROUND(SUM(SALARY),2) SUM_SAL, COUNT(EMPLOYEE_ID) 부서원수
FROM EMPLOYEES
WHERE DEPARTMENT_ID IS NOT NULL -- NULL 제외
GROUP BY DEPARTMENT_ID,JOB_ID
ORDER BY 1;

08. 부서코드 10, 20, 30, 40, 60 번 부서에 속한 사원들의
부서원수, 부서급여 평균 조회
SELECT DEPARTMENT_ID 부서, ROUND(AVG(SALARY),2) AVG_SAL, ROUND(SUM(SALARY),2) SUM_SAL, COUNT(EMPLOYEE_ID) 부서원수
FROM EMPLOYEES
WHERE DEPARTMENT_ID in(10,20,30,40,60)
GROUP BY DEPARTMENT_ID
ORDER BY 1;

09. clerk 종류의 업무별로 사원수, 사원 급여 평균 조회
SELECT JOB_ID, ROUND(AVG(SALARY),2) AVG_SAL, COUNT(*) 부서원수
FROM EMPLOYEES
WHERE lower(JOB_ID) like '%clerk%'
GROUP BY JOB_ID
ORDER BY 1;

-----------------------------------------------------------------------------
GROUP BY 외 결과행에 대해 특정 조건에 맞는 데이터 행으 ㄹ 조회하기 위한 조건절
 : HAVING 절 사용
   WHERE 절에서 사용하는 조건절은 HAVING 절에서도 사용가능
   그룹함수가 포함된 조건은  HAVING 절에서만 사용가능
   즉, WHERE   : 일반조건만 가능, 그룹함수 조건은 안돰
       HAVING  : 일반조건, 그룹함수 조건 모두 사용가능 , 반드시 GROUP BY절 사용
       
10. 80번 부서의 부서와 급여 평균 조회
SELECT EMPLOYEE_ID, ROUND(AVG(SALARY)) AVG_SAL
FROM EMPLOYEES
--WHERE DEPARTMENT_ID=80
GROUP BY  DEPARTMENT_ID;
11.각부서별로 소속된 사원의 수가 5명 이하인 부서와 그 수를 조회
SELECT DEPARTMENT_ID, COUNT(*) cnt
FROM EMPLOYEES
--WHERE  COUNT(*) <=5 --XXX WHERE : 그룹함수 사용 불가
GROUP BY DEPARTMENT_ID
HAVING COUNT(*) <=5 AND  DEPARTMENT_ID IS NOT NULL
ORDER BY 1;

12. 각 부서별 사원의
사원수가 10명 이상인 부서의
부서코드, 사원수, 급여 평균, 최대급여, 최저 급여 조회
SELECT  DEPARTMENT_ID, COUNT(*) CNT , ROUND(AVG(SALARY)) AVG_SAL, SUM(SALARY) SUM_SAL
FROM EMPLOYEES
GROUP BY DEPARTMENT_ID
HAVING COUNT(*) >= 10
ORDER BY 1;

-----------------------------------------------------------------------------
ROLLUP
GROUP BY 절에서 ROLLUP 함수를 사용하여 GROUP BY 구문에 의한 결과와 함께
단곔별 소계, 총계를 구함
※ GROUP BY 절에서 ROLLUP으로 묶은 컬럼표현에 대해 총계를 구해줌
-----------------------------------------------------------------------------
01. 각 부서별, 업무별 사원수와 급여합계, 부서별 소계, 총계를 조회한다
SELECT DEPARTMENT_ID, JOB_ID, COUNT(*) 사원수,
       SUM(SALARY) 급여합계
FROM EMPLOYEES
--WHERE
GROUP BY ROLLUP(DEPARTMENT_ID, JOB_ID)
ORDER BY DEPARTMENT_ID;

------------------------------------------------------------------------------
CUBE
GROUP BY 절에 CUBE함수를 사용하여
GROUP BY 구문에 의한 

01. 각 부서별, 업무별 사원수와 급여합계, 부서별 소계, 총계를 조회한다
SELECT DEPARTMENT_ID, JOB_ID, COUNT(*) 사원수,
       SUM(SALARY) 급여합계
FROM EMPLOYEES
--WHERE
GROUP BY CUBE(DEPARTMENT_ID, JOB_ID)
ORDER BY DEPARTMENT_ID;

------------------------------------------------------------------------------


1. CARTESIAN PROUCT : 곱하기
WHERE 절에 JOIN 조건을 기술하지 않아 잘못된 데이터 행의 결과를 갖는 현항
CROSS JOIN 이라고도 한다

사번, 성, 부서명 조회
SELECT EMPLOYEE_ID,LAST_NAME,LAST_NAME,DEPARTMENT_NAME
FROM EMPLOYEES, DEPARTMENTS;

2. EQUI 조인(ANSI 에서는 INNER JOIN, 교집합)
: WHERE 절에서 동등연산자(=) 를 사용하는 JOIN 형식
즉, 테이블들간에 공통으로 만족되는 값을 가진 경우의 결과를 반환
※JOIN 조건 : 컬럼의 값이 같은 컬럼에 대해 조인조건식을 설정
조인조건식(테이블명.컬럼명 = 테이블명.컬럼명)
--         테이블명.FK컬럼명 = 테이블명.PK컬럼명)

※ 테이블 조인 순서
1.FROM 절에 테이블 목록을 나열하여, 테이블명에 ALIAS 명을 지정한다
  (가독성을 높여 코드라인을 줄이기 위해)
2. 조인조건을 WHERE 절에 작성한다

SELECT E.EMPLOYEE_ID,E.LAST_NAME,LAST_NAME,D.DEPARTMENT_NAME
FROM EMPLOYEES E, DEPARTMENTS D
WHERE E.DEPARTMENT_ID = D.DEPARTMENT_ID ;

02. 사원들의 사번, 성, 부서코드, 부서명 조회

03. 사원들의 사번, 성, 업무코드, 업무제목 조회
04. 사원들의 사번, 성, 부서명, 업무제목 조회




















