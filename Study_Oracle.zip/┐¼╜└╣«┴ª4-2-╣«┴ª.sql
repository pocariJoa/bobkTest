-----------------------------------------------------------------------------------------------
--실습
--01. 성에 대소문자 무관하게 z가 포함된 성을 가진 사원들이 모두 몇명인지 파악하고자 한다.
--성에 대소문자 무관하게 z가 포함된 성을 가진 사원들의 수를 조회하시오. --5
SELECT COUNT(LAST_NAME)
FROM EMPLOYEES
--WHERE LAST_NAME LIKE '%Z%' OR LAST_NAME LIKE '%z%' ;
where UPPER(last_name) Like '%Z%';

--02. 우리회사 사원들 최고급여와 최저급여 간 급여차를 파악하고자 한다.
--우리회사 최고급여와 최저급여의 급여차를 조회하시오. --21900
SELECT ROUND(MAX(SALARY)-MIN(SALARY),2) AS BB
FROM EMPLOYEES;

--03. 우리회사에 매니저로 있는 사원들의 수를 파악하고자 한다.
--우리회사 매니저인 사원들의 수를 조회하시오. --18
SELECT COUNT(DISTINCT MANAGER_ID)
FROM EMPLOYEES;

--04. 우리회사 account 업무를 하는 사원들의 급여평균를 조회하시오.
--소수이하 2자리까지 구하시오. --7983.33
SELECT ROUND(AVG(SALARY),2) AVG
FROM EMPLOYEES
WHERE LOWER(JOB_ID) LIKE '%account%' ;


--05. 우리회사 사원들의 사번, 성, 부서코드, 급여 조회하여 부서코드 순으로 정렬한다.
SELECT EMPLOYEE_ID, LAST_NAME, DEPARTMENT_ID, SALARY
FROM EMPLOYEES
ORDER BY DEPARTMENT_ID ASC;


--06. 부서코드 50번 부서의 급여평균를 조회, 소수이하 2자리 --3475.56
SELECT ROUND(AVG(SALARY),2) AVG
FROM EMPLOYEES
WHERE DEPARTMENT_ID = 50;

-----------------------------------------------------------------------------------------------
--[연습문제 4-2]
--01. 우리회사 사원들 중 커미션을 받는 사원들이 모두 몇명인지 파악하고자 한다.
--커미션을 받는 사원의 수를 조회 --35
SELECT COUNT(*) CNT
FROM EMPLOYEES
WHERE COMMISSION_PCT IS NOT NULL;



--02. 우리회사 사원들 중 가장 먼저/나중에 입사한 사원의 입사일자 조회 --01/01/13	08/04/21
SELECT MIN(HIRE_DATE) MIN_HIRE,
       MAX(HIRE_DATE) MAX_HIRE
       FROM EMPLOYEES;




--03. 우리회사 부서코드 90번인 부서에 속한 사원들의 급여평균 조회, 소수이하 2자리 --19333.33
SELECT ROUND(AVG(SALARY),2) AVG_SAL
FROM EMPLOYEES
WHERE DEPARTMENT_ID=90;


-----------------------------------------------------------------------------------------------










