※ 제약조건 정리

1. 테이블 생성시 제약조건 생성 ☞ CREATE
CREATE TABLE 테이블명 (
  --------컬럼레벨정의방식
  컬럼명1 데이터타입(크기) CONSTRAINT 제약조건명 PRIMARY KEY,
  컬럼명2 데이터타입(크기) CONSTRAINT 제약조건명 NOT NULL,
  컬럼명3 데이터타입(크기) DEFAULT '값',
  컬럼명4 데이터타입(크기) CONSTRAINT 제약조건명 CHECK(컬럼명4 조건식),
  컬럼명5 데이터타입(크기) CONSTRAINT 제약조건명 UNIQUE,
  컬럼명6 데이터타입(크기) CONSTRAINT 제약조건명 REFERENCES  부모테이블(PK컬럼),
  
  
  --------테이블레벨 정의방식(위에서 제약 조건 미지정 했다고 가정하고)
  CONSTRAINT  제약조건명 PRIMARY KEY(컬럼명1),
  CONSTRAINT  제약조건명 CHECK(컬럼명4 조건식),
  CONSTRAINT  제약조건명 UNIQUE(컬럼명5),
  CONSTRAINT  제약조건명 FOREIGN KEY(컬럼명6)   REFERENCES  부모테이블(PK컬럼)
);

2. 테이블 생성 후 제약조건, 추가, 즉, 구조변경 ☞ ALTER
① 테이블 생성 후 NOT NUL 지정/제거 ☞ NULL 값 입력 금지
ALTER TABLE 테이블명
MODIFY  ( 컬럼명 데이터타입 [NOT] NULL )
NOT NULL : NOT NULL 지정, NULL : NULL 지엉

ALTER TABLE 테이블명
DROP CONSTRAINT  제약조건명 --SYS...로 자동 생성된 이름도 가능

② 테이블 생성 후 DEFAULT 추가 ☞ 데이터 입력/수정할때 값 미지정시 기본값 지정
          : gender CHAR(3) DEFAULT '남'
ALTER TABLE 테이블명
MODIFY  (컬럼명 데이터타입 DEFAULT '남');

③ 테이블 생성 후 CHECK 추가 ☞ 조건으로 설정된 값만 입력 허용
          : CHECK( gender IN ('남','여') )
ALTER TABLE 테이블명
ADD CONSTRAINT  제약조건명 CHECK(컬럼명 조건식)
                         ☞ CHECK( gender IN ('남','여') )

④ 테이블 생성 후 UNIQUE 추가 ☞ 중복 값 입력 금지(NULL 값은 중복입력 가능)
                                NOT NULL 과 함께 사용도 가능
                                2개 이상의 컬럼을 이용하여 기본키 지정(복합키)
ALTER TABLE 테이블명
ADD CONSTRAINT  제약조건명 UNIQUE(컬럼명);
                         ☞ UNIQUE(email)

⑤ 테이블 생성 후 PRIMARY KEY 추가 ☞ 식별자, 기본키, 주키, PK : NOT NULL + UNIQUE
                                     2개 이상의 컬럼을 이용하여 기본키 지정(복합키)
ALTER TABLE 테이블명
ADD CONSTRAINT  제약조건명 PRIMARY KEY ( 컬럼명 );
                         ☞ PRIMARY KEY ( id );  

⑥ 테이블 생성 후 FOREIGN KEY 추가 ☞ 외래키, 참조키, FK : NULL 허용,
                                     부모테이블의 PK인 컬럼을 참조
                                     다른 테이블의 컬럼을 조회해서 무결성 검사
ALTER TABLE 테이블명
ADD CONSTRAINT 제약조건명 FOREIGN KEY ( 컬럼명 ) REFERENCES 부모테이블(PK인컬럼);
                        ☞ FOREIGN KEY ( deptno ) REFERENCES dept(deptno);


⑦ 제약조건 삭제
ALTER TABLE 테이블명
DROP CONSTRAINT 제약조건명


⑧ 
- 참조 무결성 제약조건에서 부모 테이블의 참조키 컬럼에 존재하지 않는값을 
      자식테이블에 입력하면 오류가 발생한다.
- ON DELETE SET NULL 옵션은 자식 테이블이 참조하는 부모 테이블의 값이 삭제되면
      데이터 값을 NULL값으로 변경시킨다.
- ON DELETE CASCADE  옵션은 부모테이르이 부모데이타가 지워지면 
      자식테이블의 자식데이터도 지워진다.
- 자식 테이블이 존재하는 경우 부모테이블은 제거가 불가능하다.
- DROP TABLE 에서 CASCADE CONSTRAINT 옵션을 부여하면 자식테이블이 존재해도 
      부모테이블의 제거가 가능하다.

⑨ 제약조건명 변경
ALTER TABLE 테이블명
RENAME CONSTRAINT 기존제약조건명 TO 새제약조건명;

11장. VIEW(뷰) : 가상의 테이블
- 실제로 데이터가 존재하는 객체는 아니다
- 테이블의 데이터를 뷰를 통해 접근한다.
  1. 보안 - 접근권한
  2. 복잡한 쿼리문을 단순한 쿼리문으로 사용할 수 있다.

뷰를 사용하면 테이블처럼 사용가능하며 SELECT 절에서만 쿼리 가능
INSERT, DELETE, UPDATE 가 불가능하다.

※ 뷰 생성
CREATE OR REPLACE VIEW 뷰명 AS ☜ CVAS
  SELECT 쿼리문

* CTAS
CREATE TABLE 테이블명 AS  ☞ CTAS
  SELECT 쿼리문 
  
* ITAS
INSERT INTO 테이블 ☞ AS 없음, ITAS
  SELECT 쿼리문

CREATE OR REPLACE VIEW view_60 AS 
  SELECT  employee_id, first_name || ' ' || last_name name, 
          department_id, job_id, hire_date, email
  FROM    employees
  WHERE   department_id = 60;

60번 부서의 VIEW테이블 정보 조회
SELECT  *
FROM    view_60;

※ VIEW 삭제
DROP VIEW 뷰명
DROP VIEW view_60;

※ 연속적인 일련번호(중복되지 않은것)를 만들어주는 객체
  : SEQUENCE

* 시퀀스를 생성
CREATE  SEQUENCE  시퀀스명
START WITH  시작숫자
INCREMENT BY 증감숫자


DROP TABLE emp;
CREATE  TABLE emp (
  id    NUMBER(4) PRIMARY KEY,
  name  VARCHAR2(30) NOT NULL
);

SELECT  *
FROM    emp;

시퀀스 생성
CREATE  SEQUENCE  emp_seq
START WITH 1
INCREMENT BY 1;

현재 시퀀스 값 확인
SELECT  emp_seq.CURRVAL FROM dual; --한번도 실행 안해서 에러

시퀀스 값 접근 : CURRVAL(현재값), NEXTVAL(다음값)


SELECT  emp_seq.NEXTVAL FROM dual; --1, 한번도 실행 안해서 초기값 조회

현재 시퀀스 조회
SELECT  emp_seq.CURRVAL FROM dual; --1

emp 테이블의 PK인 id 컬럼에 시퀀스를 적용하여 데이터 행을 삽입저장한다.
DESC emp;
INSERT INTO emp
VALUES (emp_seq.CURRVAL,'이순신');

INSERT INTO emp
VALUES (emp_seq.NEXTVAL,'강감찬');

SELECT  *
FROM    emp;

* 시퀀스 삭제
DROP SEQUENCE 시퀀스명;
DROP SEQUENCE emp_seq;




























































