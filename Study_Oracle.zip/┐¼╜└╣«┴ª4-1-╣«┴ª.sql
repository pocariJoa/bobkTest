-----------------------------------------------------------------------------------------------
--[연습문제 4-1]
--우리회사에 매니저로 있는 사원들이 누군인지 파악하고자 한다.
--매니저인 사원들의 manager_id 를 조회 --18개
SELECT DISTINCT MANAGER_ID --DISTINCT : NULL 포함
FROM EMPLOYEES
WHERE MANAGER_ID IS NOT NULL
ORDER BY 1;

※ 그룹함수
1.데이터 행의 갯수를 세어 반환하는 함수 : COUNT (컬럼명),COUNT(*)
01. 우리회사 사원수 조회
SELECT COUNT(EMPLOYEE_ID) CNT1,
       COUNT(*) CNT2
FROM EMPLOYEES;

02. 우리회사에서 부서 배치를 받은 사원수
SELECT COUNT(*) cnt1 ----107
FROM EMPLOYEES;

SELECT COUNT(EMPLOYEE_ID) cnt1 ----106
FROM EMPLOYEES;

SELECT COUNT(*) cnt1 ----106
FROM EMPLOYEES 
where DEPARTMENT_ID is not null;

03. 우리회사 부서 조회
select distinct DEPARTMENT_ID
from employees
where DEPARTMENT_ID is not null;

04. 우리회사 매니저인 사원 조회
SELECT DISTINCT MANAGER_ID --107 DISTINCT : 중복제거 널포함 19
FROM EMPLOYEES
WHERE MANAGER_ID IS NOT NULL 
ORDER BY 1;--NULL제외 18

05. 우리회사 부서수 조회 --11
SELECT COUNT(DISTINCT DEPARTMENT_ID) CNT
FROM EMPLOYEES
WHERE DEPARTMENT_ID IS NOT NULL;
06. 매니저 사원의 수 조회 --18
SELECT COUNT(DISTINCT MANAGER_ID) CNT
FROM EMPLOYEES
WHERE MANAGER_ID IS NOT NULL;

07. 우리회사 사원수, 부서배치 받은 사원수, 부서, 커미션받는 사원수 조회
SELECT COUNT(*) 사원수,COUNT(DEPARTMENT_ID)"배치받은 사원수", COUNT(DISTINCT DEPARTMENT_ID) 부서 , COUNT( COMMISSION_PCT) "커미션받는 사원수"
FROM EMPLOYEES;

2. 데이터 값을 합하는 함수: SUM(컬럼명)
01.우리회사 1달 급여의 합계 조회
SELECT SUM(SALARY) SUM_SAL
FROM EMPLOYEES;

02. 60번 부서으 급여합계
SELECT SUM(SALARY) SUM_SAL
FROM EMPLOYEES
WHERE DEPARTMENT_ID = 60;

03. 60번 부서의 급여 합계(통화기호, 세자리마다 컴마붙임)
SELECT TO_CHAR(SUM(SALARY),'FML999,999') SUM_SAL1,
       TRIM(TO_CHAR(SUM(SALARY),'L999,999')) SUM_SAL2
FROM EMPLOYEES
WHERE DEPARTMENT_ID = 60;

3. 데이터값 중 가장 큰/작은 값을 반환하는 함수 : MAX/MIN(컬럼명)
01. 우리 회사 사원들 중 급여가 가장 높은/낮은 급여를 파악
SELECT MAX(SALARY) MAX_SAL1,
       MIN(SALARY) MAX_SAL2
FROM EMPLOYEES;

02. 우리 회사 사원들중 가장 먼저/나중에 나오는 성을 조회
SELECT MIN(LAST_NAME) MIN_NAME,
       MAX(LAST_NAME) MAX_NAME
FROM EMPLOYEES;

03. 우리 회사 사원들중 가장 먼저/나중에 입사한 사원의 입사일자 조회
SELECT MIN(HIRE_DATE) MIN_HIRE,
       MAX(HIRE_DATE) MAX_HIRE
       FROM EMPLOYEES;

04. 60번 부서 사원들중 급여가 가장 높은/낮은 급여 파악
SELECT MAX(SALARY) MAX_SAL1,
       MIN(SALARY) MAX_SAL2
FROM EMPLOYEES
WHERE DEPARTMENT_ID=60 ;

05. 우리회사 clerk 종류의 업무를 하는 사원들의 입사정보를 파악하여
가장 먼저 입사한 입사일자, 가장 나중에 입사한 입사일자
SELECT MIN(HIRE_DATE) MIN_HIRE,
       MAX(HIRE_DATE) MAX_HIRE
FROM EMPLOYEES
WHERE LOWER(JOB_ID) LIKE '%clerk%';

4. 데이터값의 평균을 반환하는 함수 : AVG (컬럼명)

01. 우리회사 사원들의 평균 급여 조회
급여평균은 소수 둘째자리까지 반올림해서 표현
SELECT ROUND(AVG(SALARY),2) AVG_SAL
FROM EMPLOYEES;

02. 60번 부서의 평균 급여 조회
급여평균은 소수 둘째자리까지 반올림해서 표현
SELECT ROUND(AVG(SALARY),2) AVG_SAL
FROM EMPLOYEES
WHERE DEPARTMENT_ID=60;

02. clerk 종류의 업무를 수행하는 평균 급여
급여평균은 소수 둘째자리까지 반올림해서 표현
SELECT ROUND(AVG(SALARY),2) AVG_SAL
FROM EMPLOYEES
WHERE LOWER(JOB_ID) LIKE '%clerk%';

-----------------------------------------------------------------------------------------------