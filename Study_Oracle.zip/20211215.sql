11. 사원들의 업무코드를 파악하고자 한다
업무코드가 _A 인 사원들의
사번, 성, 업무코드를 조회
SELECT EMPLOYEE_ID, LAST_NAME, JOB_ID
FROM EMPLOYEES
WHERE JOB_ID LIKE '%?_A%' ESCAPE '?';

※ LIKE 연산자와 함께 사용된 %, _ 를 문자 자체로 인식시키려면
%,_ 앞에 특수문자를 붙이고 옵션 (ESCAPE)를 지정한다
특수문자 : ~, !, @, #, $, ^, &, *, -, ?, \

SELECT EMPLOYEE_ID, LAST_NAME, JOB_ID
FROM EMPLOYEES
WHERE JOB_ID LIKE '%\__A%' ESCAPE '\'; --첫번째 _ : 문자_, 두번째_: 한글자A가 포함된
--'_'를 포함하고 A앞에 한글자 있는

8. 데이터 값이 없는 형태의 표현 : NULL - 비교불가, 산술연산 불가
그래서, 컬럼 IS NULL / IS NOT NULL 로 판단 : NULL 인지 아닌지 파악
SELECT *
FROM LOCATIONS
--WHERE STATE_PROVINCE LIKE '%'; --% : 모든것(값이있는) , NULL제외
WHERE STATE_PROVINCE IS NOT NULL; -- NULL 이 아닌 (즉, 값이있는)

01. 부서배치 받지 않은 사원들의
사번, 성, 부서코드, 업무코드, 급여 조회
SELECT EMPLOYEE_ID, LAST_NAME, DEPARTMENT_ID, JOB_ID, SALARY
FROM EMPLOYEES
WHERE DEPARTMENT_ID IS NULL;

02. 커미션을 받는 사원들의
사번, 성, 부서코드, 커미션요율 조회
SELECT EMPLOYEE_ID, LAST_NAME, DEPARTMENT_ID, COMMISSION_PCT
FROM EMPLOYEES
WHERE COMMISSION_PCT IS NOT NULL;

SELECT COMMISSION_PCT
FROM employees;
2.4 데이터행 정렬 - ORDER BY 절 : 쿼리문의 가장 마지막에 위치
ORDER BY 정렬기준표현 + ASC(오름차순, 기본값, 생략시, 오름차순)
ORDER BY 정렬기준표현 + DESC(내림차순)
※ 정렬기준표현 : 컴럼표현(컬럼명) , ALIAS명, SELECT 목록에서의 위치(컬럼번호)

SELECT 
FROM
WHERE
GROUP BY
HAVING
ORDER BY 

01. 80번 부서의 사번, 성, 급여, 부서코드에 대해 성을 오름차순으로 정렬
SELECT EMPLOYEE_ID,LAST_NAME 성, SALARY, DEPARTMENT_ID
FROM EMPLOYEES
WHERE DEPARTMENT_ID=80
--ORDER BY LAST_NAME;
--ORDER BY 성; ALIAS명
ORDER BY 2;--컬럼위치번호

02. 60번 부서의 사번, 성, 연봉에 대해 연봉을 기준으로 내림차순 정렬후 조회
SELECT EMPLOYEE_ID,LAST_NAME 성, SALARY, DEPARTMENT_ID
FROM EMPLOYEES
WHERE DEPARTMENT_ID=60
ORDER BY SALARY*12 DESC;

03. 사번, 성, 부서코드, 급여, 입사일자 조회
부서코드 순, 급여는 내림차순 조회
SELECT EMPLOYEE_ID, LAST_NAME, DEPARTMENT_ID, SALARY, HIRE_DATE
FROM EMPLOYEES
ORDER BY DEPARTMENT_ID ASC, SALARY DESC;

NULL 은 오름차순일때는 맨뒤에 위치(즉, 마지막 순위를 가짐)
NULL 은 내림차순일때는 맨앞에 위치(즉, 우선 순위를 가짐)
오름차순일떄 NULL을 맨 앞에 위치시키려면 NULLS FIRST 옵션지정
내림차순일떄 NULL을 맨 뒤에 위치시키려면 NULLS LAST  옵션지정

SELECT *
FROM LOCATIONS
ORDER BY STATE_PROVINCE ASC;

SELECT *
FROM LOCATIONS
ORDER BY STATE_PROVINCE ASC NULLS FIRST;

SELECT *
FROM LOCATIONS
ORDER BY STATE_PROVINCE DESC NULLS LAST;


3장. 기본함수(단일 결과행)
 : 숫자함수, 문자함스, 날짜함수, 형변환함수, 일반함수
 함수의 유형 : 단일결과행 함수, 다중결과행 함수
 함수에 사용하는 파라미터와 반환된 값의 유형의 따라함수를 구분
 단일결과행 함수 : 하나의 데이터 행에 대해 하나의 결과를 반환하는 함수
 숫자함수 : ROUND , TRUNC, CETL, FLOOR
 문자함수 : UPPER, LOWER, TRIM, LTRIM/RTRIM, LPAD/RPAD
          : SUBSTR, INSTR, REPLACE, TRANSLATE
 날짜함수 : SYSDATE, MONTHS_BETWEEN, ADD_MONTHS, LAST_DAY
 형변환함수 : TO_CHAR, TO_DATE, TO_NUMBER
 일반함수 : NVL, MVL2, COALESCE, DECODE, CASE~END
 
 데이터 테스트를 위한 레이블 : dummy talbe -> dual , 실제로 데이터는 들어가 있지 않음
 
3.1 숫자함수
ABS(N) : N의 절대값을 반환
SELECT ABS(32), ABS(-32)
FROM dual;

SIGN(N) : N이 양수면 1, N이 음수면 -1, 0이면 0을 반환
SELECT SIGN(32), SIGN(-32), SIGN(0)
FROM DUAL;

1)반올림 함수 : ROUND(숫자, 소수이하/이상 자릿수)
소수이상/이상 자릿수 : 음수 지정 가능, 생략시 기본값은 0 , 즉, 정수로 표시
SELECT ROUND(1234.5678,2) r1,
       ROUND(1234.5678,1) r2,
       ROUND(1234.5678,0) r3,
       ROUND(1234.5678,-2) r4
FROM DUAL;

2) 무조건 버림 함수 : TRUNC(숫자, 소수이하/이상 자릿수)
SELECT TRUNC(1234.5678,2) r1,
       TRUNC(1234.5678,1) r2,
       TRUNC(1234.5678,0) r3,
       TRUNC(1234.5678,-2) r4
FROM DUAL;

3) 숫자보다 같거나 큰 정수를 반환하는 함수 : CEIL(N)-무조건 올림의 정수
게시판에서 페이지 나눌때(페이징처리)
SELECT CEIL(0.999999999) C1,
       CEIL(0.0000000001) C2,
       CEIL(0) C3,
       CEIL(1.111111111) C4
FROM  DUAL;

4) 숫자보다 같거나 작은 정수를 반환하는 함수 :FLOOR(n) - 무조건 내림의 정수
SELECT FLOOR(0.99999999) f1,
       FLOOR(0.0000001) f2,
       FLOOR(0) f3,
       FLOOR(1.111111111) f4
FROM dual;

숫자 데이터를 표현할수있는 함수 : ROUND, TRUNC, CEIL, FLOOR
소숫점 데이터를 표현할수있는 함수 : ROUND, TRUNC
점수 데이터를 표현할수있는 함수 : CEIL, FLOOR, ROUND, TRUNC(2번째 파라미터가 0)

5) 나머지를 반환하는 함수 : MOD(피젯수, 젯수)
SELECT MOD(17,4) M1,
       MOD(17,-4) M2,
       MOD(-17,4) M3,
       MOD(-17,-4) M4,
       MOD(-17,0) M4
FROM DUAL;

--------------------------------------------------------------------------------
피젯수    젯수             젯수      몫       나머지
17    /    4    :    17  =   4   *   4      +   1
--------------------------------------------------------------------------------

3.2 문자함수
1. 대/소문자 변환함수 : UPPER/LOWER(문자)
   UPPER(대문자), LOWER(소문자)
01. 성이 King 인 사원들의 사번, 성, 명 조회
select EMPLOYEE_ID, LAST_NAME, FIRST_NAME
from EMPLOYEES
WHERE  LAST_NAME ='King';

select EMPLOYEE_ID, LAST_NAME, FIRST_NAME
from EMPLOYEES
WHERE  lower(LAST_NAME) ='king';

select EMPLOYEE_ID, LAST_NAME, FIRST_NAME
from EMPLOYEES
WHERE  upper(LAST_NAME) ='KING';

02. 성에 대소문자 무과하게 z가 있는 사원들의
사번, 성, 명 조회
select EMPLOYEE_ID,FIRST_NAME, LAST_NAME
from EMPLOYEES
where LAST_NAME LIKE '%z%'
or LAST_NAME LIKE '%Z%';

select EMPLOYEE_ID,FIRST_NAME, LAST_NAME
from EMPLOYEES
where lower(LAST_NAME) like '%z%';

2. 단어 단윌 첫문자는 대문자, 나머지는 소문자로 변환하는 함수 : INITCAP(대상)
SELECT 'we are stuyding oracle' t1,
       initcap('we are stuyding oracle') t2,
       initcap('WE ARE STUYDING ORACLE') t3,
       initcap('wE aRE sTUYDING oRACLE') t4
from dual;

select email, initcap(email) initcap,
       first_name ,upper(FIRST_NAME), lower(FIRST_NAME)
from EMPLOYEES;



