SELECT * FROM com_qna_a;

SELECT * FROM user_answer;

SELECT answer, (SELECT ans1  FROM user_answer) SS FROM com_qna_a WHERE no=1;

SELECT ans10  FROM user_answer;

SELECT ANSWER, (SELECT ANS1  FROM user_answer) SS FROM com_qna_a WHERE no=1;

CREATE TABLE USER_ANSWER2(
     ID       VARCHAR2(30),
     NO NUMBER(2) DEFAULT 0,
     ANS     NUMBER(2) DEFAULT 0
);
insert into USER_ANSWER2 values ('user1',1,3);
insert into USER_ANSWER2 values ('user2',2,2);
insert into USER_ANSWER2 values ('user3',3,3);
insert into USER_ANSWER2 values ('user4',4,1);
insert into USER_ANSWER2 values ('user5',5,1);
insert into USER_ANSWER2 values ('user6',6,4);
insert into USER_ANSWER2 values ('user7',7,2);
insert into USER_ANSWER2 values ('user8',8,1);
insert into USER_ANSWER2 values ('user9',9,3);
insert into USER_ANSWER2 values ('user10',10,4);

select b.answer ,a.ans from USER_ANSWER2 a, com_qna_a b where a.NO = b.NO;

select * from USER_ANSWER2;
drop TABLE USER_ANSWER2;