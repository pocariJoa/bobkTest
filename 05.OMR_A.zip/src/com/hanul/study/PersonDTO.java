package com.hanul.study;

public class PersonDTO {
	
	private String	id       ;
	private int	ans1     ;
	private int	ans2     ;
	private int	ans3     ;
	private int	ans4     ;
	private int	ans5     ;
	private int	ans6     ;
	private int	ans7     ;
	private int	ans8     ;
	private int	ans9     ;
	private int	ans10    ;
	
	public PersonDTO() {}
	
	public PersonDTO(String id, int ans1, int ans2, int ans3, int ans4, int ans5, int ans6, int ans7, int ans8,
			int ans9, int ans10) {
		super();
		this.id = id;
		this.ans1 = ans1;
		this.ans2 = ans2;
		this.ans3 = ans3;
		this.ans4 = ans4;
		this.ans5 = ans5;
		this.ans6 = ans6;
		this.ans7 = ans7;
		this.ans8 = ans8;
		this.ans9 = ans9;
		this.ans10 = ans10;
	}

	public int getAns1() {
		return ans1;
	}

	public void setAns1(int ans1) {
		this.ans1 = ans1;
	}

	public int getAns2() {
		return ans2;
	}

	public void setAns2(int ans2) {
		this.ans2 = ans2;
	}

	public int getAns3() {
		return ans3;
	}

	public void setAns3(int ans3) {
		this.ans3 = ans3;
	}

	public int getAns4() {
		return ans4;
	}

	public void setAns4(int ans4) {
		this.ans4 = ans4;
	}

	public int getAns5() {
		return ans5;
	}

	public void setAns5(int ans5) {
		this.ans5 = ans5;
	}

	public int getAns6() {
		return ans6;
	}

	public void setAns6(int ans6) {
		this.ans6 = ans6;
	}

	public int getAns7() {
		return ans7;
	}

	public void setAns7(int ans7) {
		this.ans7 = ans7;
	}

	public int getAns8() {
		return ans8;
	}

	public void setAns8(int ans8) {
		this.ans8 = ans8;
	}

	public int getAns9() {
		return ans9;
	}

	public void setAns9(int ans9) {
		this.ans9 = ans9;
	}

	public int getAns10() {
		return ans10;
	}

	public void setAns10(int ans10) {
		this.ans10 = ans10;
	}
	
	
	
}
