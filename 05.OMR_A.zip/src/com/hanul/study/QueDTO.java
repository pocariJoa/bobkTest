package com.hanul.study;

import java.util.ArrayList;

public class QueDTO {
	private int no;
	private String question;
	private int answer;
	
	public QueDTO() {}
	
	public QueDTO(int no, String question, int answer) {
		super();
		this.no = no;
		this.question = question;
		this.answer = answer;
	}

	public QueDTO(ArrayList<QueDTO> alist) {
		// TODO Auto-generated constructor stub
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public int getAnswer() {
		return answer;
	}

	public void setAnswer(int answer) {
		this.answer = answer;
	}
	
	
	
}
