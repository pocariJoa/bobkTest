package com.hanul.study;

public class WHDGKQDTO {
	
	private int answer ;
	private int ANS1, ANS2, ANS3, ANS4, ANS5, ANS6, ANS7, ANS8, ANS9, ANS10;
	
	public WHDGKQDTO(int answer, int aNS1, int aNS2, int aNS3, int aNS4, int aNS5, int aNS6, int aNS7, int aNS8,
			int aNS9, int aNS10) {
		super();
		this.answer = answer;
		ANS1 = aNS1;
		ANS2 = aNS2;
		ANS3 = aNS3;
		ANS4 = aNS4;
		ANS5 = aNS5;
		ANS6 = aNS6;
		ANS7 = aNS7;
		ANS8 = aNS8;
		ANS9 = aNS9;
		ANS10 = aNS10;
	}
	
	
}
