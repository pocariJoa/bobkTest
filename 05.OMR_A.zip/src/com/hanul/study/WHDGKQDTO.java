package com.hanul.study;

public class WHDGKQDTO {
	
	private int answer ;
	private int user_ans;
	
	public WHDGKQDTO() {}

	public WHDGKQDTO(int answer, int user_ans) {
		super();
		this.answer = answer;
		this.user_ans = user_ans;
	}

	public int getAnswer() {
		return answer;
	}

	public void setAnswer(int answer) {
		this.answer = answer;
	}

	public int getUser_ans() {
		return user_ans;
	}

	public void setUser_ans(int user_ans) {
		this.user_ans = user_ans;
	}
	
	
	
	
}
