package com.hanul.study;

public class UserAnswerDTO {
	private int answer, useranswer;
	
	public UserAnswerDTO() {}
	
	public UserAnswerDTO(int answer, int useranswer) {
		super();
		this.answer = answer;
		this.useranswer = useranswer;
	}

	public int getAnswer() {
		return answer;
	}

	public void setAnswer(int answer) {
		this.answer = answer;
	}

	public int getUseranswer() {
		return useranswer;
	}

	public void setUseranswer(int useranswer) {
		this.useranswer = useranswer;
	}
	
	
}
