package com.hanul.study;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class TestDAO {
	
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	
	//DB 접속하기
	public Connection getConn() {
		try {
			String url = "jdbc:oracle:thin:@127.0.0.1:1521:XE";
			String user = "hanul";
			String password = "0000";
			Class.forName("oracle.jdbc.driver.OracleDriver"); //동적로딩
			conn  = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("getConn() Exception!!");
		}
		return conn;
	}//getConn()
	
	//DB 접속 해제 메소드
	public void dbClose() {
		try {
			if(rs != null) rs.close();
			if(ps != null) ps.close();
			if(conn != null) conn.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("dbClose() Exception !!");
		}
	}//dbClose()
	
	//정답불러오기
	public ArrayList<QueDTO> right() {
		conn = getConn();
		String sql = " SELECT ANSWER FROM COM_QNA_A ";
		ArrayList<QueDTO> list = new ArrayList<>();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				QueDTO dto = new QueDTO();
				dto.setAnswer(rs.getInt("answer"));
				list.add(dto);
			}
		}catch (Exception e) {
			// TODO: handle exception
		}finally {
			dbClose();
		}
		return list; 
	}
	
	//사용자 답안 가져오기
	public ArrayList<PersonDTO> person(){
		conn = getConn();
		String sql = " SELECT * FROM USER_ANSWER ";
		ArrayList<PersonDTO> list = new ArrayList<>();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				PersonDTO dto = new PersonDTO();
				dto.setAns1(rs.getInt("ans1"));
				dto.setAns2(rs.getInt("ans2"));
				dto.setAns3(rs.getInt("ans3"));
				dto.setAns4(rs.getInt("ans4"));
				dto.setAns5(rs.getInt("ans5"));
				dto.setAns6(rs.getInt("ans6"));
				dto.setAns7(rs.getInt("ans7"));
				dto.setAns8(rs.getInt("ans8"));
				dto.setAns9(rs.getInt("ans9"));
				dto.setAns10(rs.getInt("ans10"));
				list.add(dto);
			}
		}catch (Exception e) {
			// TODO: handle exception
		}finally {
			dbClose();
		}
		return list; 
	}
	
	//사용자 답안
	public ArrayList<PersonDTO> pList (){
		conn = getConn();
		String sql = " SELECT * FROM USER_ANSWER ";
		ArrayList<PersonDTO> pList = new ArrayList<>();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				PersonDTO dto = new PersonDTO();
				dto.setAns1(rs.getInt("ans1"));
				dto.setAns2(rs.getInt("ans2"));
				dto.setAns3(rs.getInt("ans3"));
				dto.setAns4(rs.getInt("ans4"));
				dto.setAns5(rs.getInt("ans5"));
				dto.setAns6(rs.getInt("ans6"));
				dto.setAns7(rs.getInt("ans7"));
				dto.setAns8(rs.getInt("ans8"));
				dto.setAns9(rs.getInt("ans9"));
				dto.setAns10(rs.getInt("ans10"));
				pList.add(dto);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			dbClose();
		}
		return pList;
	}
	
	
	//제대로
	public ArrayList<WHDGKQDTO> ssList (){
		ArrayList<WHDGKQDTO> ssList = new ArrayList<>();
		WHDGKQDTO dto = new WHDGKQDTO();
		conn = getConn();
		for(int a = 1; a<=10; a++) {
		String sql = "  SELECT answer, (SELECT ans"+a+"  FROM user_answer) user_ans FROM com_qna_a WHERE no="+a ;		
			try {
				ps = conn.prepareStatement(sql);							
					rs = ps.executeQuery();
					while(rs.next()) {
					dto.setAnswer(rs.getInt("answer"));
					dto.setUser_ans(rs.getInt("user_ans"));
					ssList.add(dto);
				}				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}//for 
		//finally {
			//dbClose();
		//}//finally
		return ssList;

	}//ssList()
	
	//시험용
	public ArrayList<WHDGKQDTO> ssList2 (){
		ArrayList<WHDGKQDTO> ssList = new ArrayList<>();
		WHDGKQDTO dto = new WHDGKQDTO();
		int a = 1;
		conn = getConn();
			try {
				for(a = 1; a<=8; a++) {
					String sql = "  SELECT answer, (SELECT ans"+a+"  FROM user_answer) user_ans FROM com_qna_a WHERE no="+a ;		
					ps = conn.prepareStatement(sql);							
					rs = ps.executeQuery();
					while(rs.next()) {
					dto.setAnswer(rs.getInt("answer"));
					dto.setUser_ans(rs.getInt("user_ans"));
					ssList.add(dto);
					}				
				}//for
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				dbClose();
			}//finally
		return ssList;

	}//ssList()

	//시험용2(사용자 입력답만 가져오기
	public ArrayList<UserAnswerDTO> uAnswer() {
		ArrayList<UserAnswerDTO> list = new ArrayList<>();
		conn = getConn();
		String sql = " select b.answer answer, a.test useranswer from USER_ANSWER a, COM_QNA_A b where a.no = b.no ";
		UserAnswerDTO dto = new UserAnswerDTO();
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				dto.setAnswer(rs.getInt("answer"));
				dto.setUseranswer(rs.getInt("useranswer"));
				
				list.add(dto);
			}
			
		} catch (Exception e) {
			
		}finally {
			dbClose();
		}
		return list;
	}

	
	/*
	//테이블새로만들었을때 정답과 입력한답불러오기
	public ArrayList<WHDGKQDTO> ssList (){
		conn = getConn();
		String sql = " select b.answer ,a.ans from USER_ANSWER2 a, com_qna_a b where a.NO = b.NO ";
		ArrayList<WHDGKQDTO> ssList = new ArrayList<>();
		try {
			ps =conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				WHDGKQDTO dto = new WHDGKQDTO();
				dto.setAnswer(rs.getInt("answer"));
				dto.setAns(rs.getInt("ans"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			dbClose();
		}
		return ssList;
	}
	*/
	
	//다 불러오기
	public void list() {
		conn = getConn();
		String sql = " select ANSWER, (SELECT a.ans1 FROM USER_ANSWER A, member_a B WHERE A.ID=B.ID) ss from COM_QNA_A a ";
		
	}
}
