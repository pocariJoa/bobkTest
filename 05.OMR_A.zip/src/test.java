

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanul.study.TestDAO;

@WebServlet("/qwer.do")
public class test extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		
		TestDAO dao = new TestDAO();
		
		String aaa =request.getParameter("id");
		
		if(dao.addColumn(aaa) == 1) {
			response.sendRedirect("http://www.daum.net");
		}else {
			response.sendRedirect("http://www.naver.com");
		}
	}

}
