import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanul.study.PersonDTO;
import com.hanul.study.QueDTO;
import com.hanul.study.TestDAO;

@WebServlet("/r.do")
public class ResultServlet extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException {
		// ①클라이언트의 요청을 받는다 : HttpServletRequest
		//폼에서 입력한 매개변수 값을 가져온다 : getParameter();
		request.setCharacterEncoding("utf-8");
		
		//② 비지니스 로직 : 별도의 클래스에 작성(Model) ▶ com.hanul.study package
		TestDAO dao = new TestDAO();
		
		ArrayList<QueDTO> alist = dao.right();//정답목록
		
		
		
		
		
		/*
		ArrayList<QueDTO> alist = dao.right();//정답목록
		ArrayList<PersonDTO> plist = dao.person();//사용자답안
		//QueDTO dto = new QueDTO(alist);
		
		request.setAttribute("alist", alist);
		RequestDispatcher rd =request.getRequestDispatcher("result.jsp");
		rd.forward(request, response);
		*/
		
		//답안, 누른답안 각각 불러와
	}

}
