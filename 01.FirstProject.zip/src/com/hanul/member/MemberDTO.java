package com.hanul.member;

import java.io.Serializable;

public class MemberDTO implements Serializable {//객체의 직렬화
	//멤버변수(필드) 선언 : 정보은닉 → private
	private String memberName;
	private String memberId;
	private String memberPw;
	private int memberAge;
	private String memberAddr;
	private String memberTel;
	
	//디폴트 생성자 메소드 : 메소드명과 클래스명이 일치, 리턴타입이 존재하지 않는다
	public MemberDTO() {}
	
	//생성자 메소드 초기화 : 멤버변수(필드가 하나로 묶어진다
	public MemberDTO(String memberName, String memberId, String memberPw, int memberAge, String memberAddr,
			String memberTel) {
		super();
		this.memberName = memberName;
		this.memberId = memberId;
		this.memberPw = memberPw;
		this.memberAge = memberAge;
		this.memberAddr = memberAddr;
		this.memberTel = memberTel;
	}
	
	//Getters & Setters 메소드 : 멤버변수에 접근(출력: Getter Method, 입력 : Setter Method)
	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getMemberPw() {
		return memberPw;
	}

	public void setMemberPw(String memberPw) {
		this.memberPw = memberPw;
	}

	public int getMemberAge() {
		return memberAge;
	}

	public void setMemberAge(int memberAge) {
		this.memberAge = memberAge;
	}

	public String getMemberAddr() {
		return memberAddr;
	}

	public void setMemberAddr(String memberAddr) {
		this.memberAddr = memberAddr;
	}

	public String getMemberTel() {
		return memberTel;
	}

	public void setMemberTel(String memberTel) {
		this.memberTel = memberTel;
	}
	
	
	
}
