

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanul.member.MemberDTO;

/**
 * Servlet implementation class MemberJoinAction
 */
@WebServlet("/memberJoin.do")//자동설정된 Mapping
public class MemberJoinAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//클라이언트의 요청을 받는다 : 매개변수를 가져온다 ▶ request.getParameter();
		request.setCharacterEncoding("utf-8");//인코딩 설정
		String memberName =request.getParameter("memberName");
		String memberId = request.getParameter("memberId");
		String memberPw = request.getParameter("memberPw");
		int memberAge = Integer.parseInt(request.getParameter("memberAge"));
		String memberAddr = request.getParameter("memberAddr");
		String memberTel = request.getParameter("memberTel");
		
		System.out.println("이름 : "+memberName);
		System.out.println("아이디 : "+memberId);
		System.out.println("비밀번호 : "+memberPw);
		System.out.println("나이 : "+memberAge);
		System.out.println("주소 : "+memberAddr);
		System.out.println("전화번호 : "+memberTel);
		
		//전달받은 매개변수를 하나의 객체로 묶는다(MemberDTO),
		MemberDTO dto = new MemberDTO(memberName, memberId, memberPw, memberAge, memberAddr, memberTel);
		
		//비지니스 로직 : DAO를 통해 DB와 연동하여 회원가입(insert)을 처리하고 결과를 리턴받는 작업
		//DB 연동 : MemberDAO.java -> insertMember(dto) ; ▶ 생략
		
		//프리젠테이션 로직 : 리턴받은 결괄 클라이언트에게 응답(html, jsp)
		request.setAttribute("dto", dto); //바인딩(연결) 객체
		RequestDispatcher rd =request.getRequestDispatcher("result.jsp"); //페이지 호출
		rd.forward(request, response);//페이지 전환
		
		
		
	}
}//class
