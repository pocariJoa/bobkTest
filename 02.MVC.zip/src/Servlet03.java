import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanul.study.MemberDAO;
import com.hanul.study.MemberDTO;


@WebServlet("/s03.do")
public class Servlet03 extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		// ① 클라이언트의 요청을 받는다 : 폼에서 입력한 매개변수를 가져온다.
		
		/* DTO 클래스의 초기화된  생성자 메소드를  이용하여 DTO객체를 생성하는 방법
		request.setCharacterEncoding("utf-8");//인코딩 설정
		String memberName = request.getParameter("memberName");
		String memberId = request.getParameter("memberId");
		String memberPw = request.getParameter("memberPw");
		int memberAge = Integer.parseInt(request.getParameter("memberAge"));
		String memberAddr = request.getParameter("memberAddr");
		String memberTel = request.getParameter("memberTel");
		
		MemberDTO dto = new MemberDTO(memberName, memberId, memberPw, memberAge, memberAddr, memberTel);
		*/
		
		//디폴트생성자메소드를 이용하여 DTO객체를 생성하는 방법
		request.setCharacterEncoding("utf-8");
		MemberDTO dto = new MemberDTO();
		dto.setMemberName(request.getParameter("memberName"));
		dto.setMemberId(request.getParameter("memberId"));
		dto.setMemberPw(request.getParameter("memberPw"));
		dto.setMemberAge(Integer.parseInt(request.getParameter("memberAge")));
		dto.setMemberAddr(request.getParameter("memberAddr"));
		dto.setMemberTel(request.getParameter("memberTel"));
		
		// ② 비지니스 로직 : DAO 클래스를 통해서 DataBase 연동 (insert)
		MemberDAO dao = new MemberDAO();
		int succ = dao.memberInsert(dto);
		
		// ③ 프리젠테이션 로직 : 결과를 응답(html)
		response.setContentType("text/html; charset=utf-8"); //MIME Type
		PrintWriter out = response.getWriter();	//출력스트림
		if(succ > 0) {
			out.println("<script>alert('회원가입 성공');</script>");
			out.println("<a href='memberJoinForm.html'>회원가입 화면으로 이동</a>");
			out.println("<br><br>");
			out.println("<a href='s04.do'>전체회원 목록보기</a>");
		}else {
			out.println("<script>alert('회원가입 실패');</script>");
			out.println("<a href='memberJoinForm.html'>회원가입 화면으로 이동</a>");
			out.println("<br><br>");
			out.println("<a href='s04.do'>전체회원 목록보기</a>");
		}
	}
}//class
