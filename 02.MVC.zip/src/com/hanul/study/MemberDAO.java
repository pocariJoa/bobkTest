package com.hanul.study;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

//Controller(Servlet)에서 넘겨준 매개변수를 이용하여 DB와 연동(insert, delete, update,select)
public class MemberDAO { 	
	private Connection conn; 		//연결객체
	private PreparedStatement ps; 	//전송객체
	private ResultSet rs; 			//결과객체(select)
	
	//DB접속 Library 등록 : ojdbc8.jar → WebContent > WEB-INF > lib  : 복&붙 ▶ 정적로딩
	//ojdbc8.jar 위치 : C:\app\hanul\product\18.0.0\dbhomeXE\jdbc\lib
	
	//DB 접속 메소드
	public Connection getConn() {
		try {
			String url = "jdbc:oracle:thin:@127.0.0.1:1521:XE";
			String user = "hanul";
			String password = "0000";
			Class.forName("oracle.jdbc.driver.OracleDriver"); //동적로딩
			conn  = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("getConn() Exception!!");
		}
		return conn;
	}//getConn()
	
	//DB 접속 해제 메소드
	public void dbClose() {
		try {
			if(rs != null) rs.close();
			if(ps != null) ps.close();
			if(conn != null) conn.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("dbClose() Exception !!");
		}
	}//dbClose()
	
	//회원가입
	public int memberInsert(MemberDTO dto) {
		conn = getConn(); // DB 접속
		String sql = " INSERT into MEMBER values ( ?,?,?,?,?,?) ";	// SQL 문장작성
		int succ = 0;		//sql 문장의 성공여부 판단ㅇ하기위한 변수 (insert, delete, update)
		try {
			ps = conn.prepareStatement(sql);	//전송객체 생성
			ps.setString(1, dto.getMemberName());
			ps.setString(2, dto.getMemberId());
			ps.setString(3, dto.getMemberPw());
			ps.setInt(4, dto.getMemberAge());
			ps.setString(5, dto.getMemberAddr());
			ps.setString(6, dto.getMemberTel());
			succ = ps.executeUpdate();			//문장을 실행
		} catch (Exception e) {
			e.printStackTrace();	//예외 발생 시 예외코드를 상세하게 출력
			System.out.println("memberInsert() Exception !!"); // 예외메세지 출력
		}finally {
			dbClose();	//DB 접속 해제
		}
		return succ;	//결과(성공여부)를 리턴
	}//memberInsert()
	
	//전체회원 목록 검색
	public ArrayList<MemberDTO> memberSearchAll() {
		conn = getConn();
		String sql = " select * from Member ";
		ArrayList<MemberDTO> list = new ArrayList<>(); //최종결과를 저장할 자료구조를 생성
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				/* DTO 클래스의 초기화된  생성자 메소드를  이용하여 DTO객체를 생성하는 방법
				String memberName = rs.getString("memberName");
				String memberId = rs.getString("memberId");
				String memberPw = rs.getString("memberPw");
				int memberAge = rs.getInt("memberAge");
				String memberAddr = rs.getString("memberAddr");
				String memberTel = rs.getString("memberTel");
				MemberDTO dto = new MemberDTO(memberName, memberId, memberPw, memberAge, memberAddr, memberTel);
				*/
				
				//디폴트생성자메소드를 이용하여 DTO객체를 생성하는 방법
				MemberDTO dto = new MemberDTO();
				dto.setMemberName(rs.getString("memberName"));
				dto.setMemberId(rs.getString("memberId"));
				dto.setMemberPw(rs.getString("memberPw"));
				dto.setMemberAge(rs.getInt("memberAge"));
				dto.setMemberAddr(rs.getString("memberAddr"));
				dto.setMemberTel(rs.getString("memberTel"));
				
				list.add(dto);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("memberSearchAll() Exception !!");
		}finally {
			dbClose();
		}
		return list;
	}//memberSearchAll()
	
	//회원정보 삭제
	public int memberDelete(String memberId) {
		conn = getConn();
		String sql = " delete from Member where memberId= ? ";
		int succ = 0;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, memberId);
			succ = ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("memberDelete Exception");
		}finally {
			dbClose();
		}
		return succ;
	}
	
}//class
