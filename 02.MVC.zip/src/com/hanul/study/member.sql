-- 테이블 생성

CREATE TABLE MEMBER(
  memberName varchar2(20),
  memberId   varchar2(20),
  memberPw   varchar2(20),
  memberAge  number,
  memberAddr varchar2(50),
  memberTel  varchar2(20)
);

--전체레코드 검색
select  * from Member;

-- 테이블 제거
drop table Member;
